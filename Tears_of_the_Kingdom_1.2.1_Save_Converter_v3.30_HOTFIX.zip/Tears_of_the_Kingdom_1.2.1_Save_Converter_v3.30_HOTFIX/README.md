# Tears of the Kingdom 1.2.1 Save Converter v3.30 HOTFIX

Created by **ThyHeroOfTime**

Edited By  *Wesley Da Man*

A user-editable converter for working between normal Tears of the Kingdom
`progress.sav` files and Zonai Hosting `.ktml` server saves.

## v3.30 HOTFIX

This version is built from the creator's latest hand-edited source files and keeps
the existing KTML numeric compatibility hotfix.

The converter normalizes Java-sensitive integer sections before writing KTML and
then reparses the exact generated text for a final numeric type validation pass.
This is designed to prevent `Double cannot be cast to Long` server crashes.

(WARNING) Always back up original `.sav` and `.ktml` files before testing converted saves.

This is an independent fan-made utility and is not affiliated with or endorsed by
Nintendo or the creators of Tears of the Kingdom.
